<?php

namespace App\Models\Other;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Other\State
 *
 * @method static \Illuminate\Database\Eloquent\Builder|State newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|State newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|State query()
 * @mixin \Eloquent
 */
class State extends Model
{
    //
}
