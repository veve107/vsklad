<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Accessories
 *
 * @method static \Illuminate\Database\Eloquent\Builder|Accessories newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Accessories newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|Accessories query()
 * @mixin \Eloquent
 */
class Accessories extends Model
{
    //
}
