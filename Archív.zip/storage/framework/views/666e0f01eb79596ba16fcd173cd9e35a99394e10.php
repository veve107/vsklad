<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/profile.css')); ?>">
    <link href="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('hardware')); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Zariadenia</h5>
            </div><!-- sl-page-title -->
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zoznam zariadení <a href="<?php echo e(route('hardware.add')); ?>"
                                                                class="btn btn-sm btn-warning"
                                                                style="float: right">Pridať nové zariadenie</a>
                </h6>
                <div class="row">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home"
                               role="tab" aria-controls="home" aria-selected="true">Dostupné zariadenia</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#devices"
                               role="tab" aria-controls="profile" aria-selected="false">Nedostupné zariadenia</a>
                        </li>
                    </ul>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel"
                                 aria-labelledby="home-tab">
                                <div class="tab-content" style="margin-top:2%">
                                    <div class="table-wrapper">
                                        <table id="datatable1" class="table display responsive nowrap" style="width: 100% !important;">
                                            <thead>
                                            <tr>
                                                <th class="wd-5p">ID</th>
                                                <th class="wd-10p">Značka</th>
                                                <th class="wd-10p">Názov zariadenia</th>
                                                <th class="wd-10p">Typ zariadenia</th>
                                                <th class="wd-10p">Druh zariadenia</th>
                                                <th class="wd-10p">Číslo objednávky</th>
                                                <th class="wd-10p">Počet kusov</th>
                                                <th class="wd-10p">Sériové číslo</th>
                                                <th class="wd-10p">Inventárne číslo</th>
                                                <th class="wd-10p">Záruka do</th>

                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $devices_available; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($device->id); ?></td>
                                                    <td><?php echo e($device->brand->name); ?></td>
                                                    <td><?php echo e($device->name); ?></td>
                                                    <td><?php echo e($device->type->name); ?></td>
                                                    <td><?php echo e($device->type->type == 1 ? "Hardvér" : "Doplnok"); ?></td>
                                                    <td><?php echo e($device->order->order_number); ?></td>
                                                    <td><?php echo e($device->stock); ?></td>
                                                    <td><?php echo e($device->serial_number); ?></td>
                                                    <td><?php echo e(empty($device->inventory_number) ? "Nenastavené" : $device->inventory_number); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($device->order->end_of_warranty)->format('d.m.Y')); ?></td>



                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- table-wrapper -->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="devices" role="tabpanel"
                                 aria-labelledby="devices-tab">
                                <div class="tab-content" style="margin-top:2%">
                                    <div class="table-wrapper">
                                        <table id="datatable2" class="table display responsive nowrap" style="width: 100% !important;">
                                            <thead>
                                            <tr>
                                                <th class="wd-5p">ID</th>
                                                <th class="wd-10p">Značka</th>
                                                <th class="wd-10p">Názov zariadenia</th>
                                                <th class="wd-10p">Typ zariadenia</th>
                                                <th class="wd-10p">Číslo objednávky</th>
                                                <th class="wd-10p">Sériové číslo</th>
                                                <th class="wd-10p">Inventárne číslo</th>
                                                <th class="wd-10p">Záruka do</th>
                                                <th class="wd-10p">Používateľ</th>

                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $devices_unavailable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($device->id); ?></td>
                                                    <td><?php echo e($device->brand->name); ?></td>
                                                    <td><?php echo e($device->name); ?></td>
                                                    <td><?php echo e($device->type->name); ?></td>
                                                    <td><?php echo e($device->order->order_number); ?></td>
                                                    <td><?php echo e($device->serial_number); ?></td>
                                                    <td><?php echo e($device->inventory_number); ?></td>
                                                    <td><?php echo e(\Carbon\Carbon::parse($device->order->end_of_warranty)->format('d.m.Y')); ?></td>
                                                    <td><?php echo e($device->requests[0]->user->name); ?></td>



                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div><!-- table-wrapper -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('#datatable1').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            $('#datatable2').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            // Select2
            $('.dataTables_length select').select2({minimumResultsForSearch: Infinity});
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hardware/hardware.blade.php ENDPATH**/ ?>