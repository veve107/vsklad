<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('types')); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Typy</h5>
            </div><!-- sl-page-title -->

            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zoznam typov zariadení
                    <button class="btn btn-sm btn-warning" id="addType" style="float: right">Pridať nový typ</button>
                </h6>

                <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                        <thead>
                        <tr>
                            <th class="wd-15p">ID</th>
                            <th class="wd-15p">Názov</th>
                            <th class="wd-15p">Druh</th>
                            <th class="wd-20p">Akcia</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($type->id); ?></td>
                                <td><?php echo e($type->name); ?></td>
                                <td><?php echo e($type->type == 1 ? "Hardvér" : "Doplnok"); ?></td>
                                <td><button class="btn btn-sm btn-info editButton"
                                       data-id="<?php echo e($type->id); ?>"
                                       data-name="<?php echo e($type->name); ?>">Editovať</button> ||
                                    <a href="<?php echo e(route('type.delete', $type->id)); ?>"
                                       class="btn btn-sm btn-danger"
                                       id="delete">Zmazať</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('#datatable1').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            $('#datatable2').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            // Select2
            $('.dataTables_length select').select2({minimumResultsForSearch: Infinity});
            $("#addType").click(function () {
                Swal.fire({
                    title: 'Pridanie nového typu techniky',
                    html:
                        '<form id="createType" method="post" action="<?php echo e(route('type.store')); ?>"> <?php echo e(csrf_field()); ?>' +
                        '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov typu">' +
                        '<select id="type" name="type" class="swal2-input" placeholder="Druh"><option value=1>Hardvér</option><option value=2>Doplnky</option></select>' +
                        '</form>',
                    focusConfirm: false,
                    customClass: 'swal2-overflow',
                    confirmButtonText: "Pridaj typ",
                    preConfirm: () => {
                        return []
                    },
                }).then(function (result) {
                    if (result.isConfirmed) {
                        $("#createType").submit();
                    }
                })
            });

            $(".editButton").click(function () {
                Swal.fire({
                    title: 'Upravenie názvu typu',
                    html:
                        '<form id="updateType" method="post" action="<?php echo e(route('type.update.dummy')); ?>/' + $(this).attr('data-id') + '"> <?php echo e(csrf_field()); ?>' +
                        '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov typu" value="' + $(this).attr('data-name') + '" >' +
                        '</form>',
                    focusConfirm: false,
                    customClass: 'swal2-overflow',
                    confirmButtonText: "Uprav názov typu",
                    preConfirm: () => {
                        return []
                    },
                }).then(function (result) {
                    if (result.isConfirmed) {
                        $("#updateType").submit();
                    }
                })
            });
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hardware/types.blade.php ENDPATH**/ ?>