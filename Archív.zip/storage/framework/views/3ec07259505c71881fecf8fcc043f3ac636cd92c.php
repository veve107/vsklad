<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Starlight">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/starlight/img/starlight-social.png">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/starlight">
    <meta property="og:title" content="Starlight">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/starlight/img/starlight-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="author" content="ThemePixels">

    <title>Starlight Responsive Bootstrap 4 Admin Template</title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('backend/lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">


    <!-- Starlight CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/starlight.css')); ?>">
</head>

<body>

<div class="ht-100v bg-sl-primary d-flex align-items-center justify-content-center">
    <div class="wd-lg-70p wd-xl-50p tx-center pd-x-40">
        <h1 class="tx-100 tx-xs-140 tx-normal tx-white mg-b-0">404!</h1>
        <h5 class="tx-xs-24 tx-normal tx-info mg-b-30 lh-5">Stránka ktorú ste hľadali neexistuje.</h5>
        <p class="tx-16 mg-b-30 tx-white-5">Stránka, ktorú ste sa pokúsili navštíviť bola presunutá alebo nikdy neexistovala. Choďte radšej <a href="<?php echo e(route('admin.home')); ?>">domov</a>.</p>
    </div>
</div><!-- ht-100v -->

<script src="<?php echo e(asset('backend/lib/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('backend/lib/popper.js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('backend/lib/bootstrap/bootstrap.js')); ?>"></script>

</body>
</html>
<?php /**PATH /var/www/html/resources/views/errors/404.blade.php ENDPATH**/ ?>