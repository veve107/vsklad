<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>

    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('detailRequest', $request)); ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul style="margin-bottom: 0!important;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Spracovanie žiadosti</h6>
                <p class="mg-b-20 mg-sm-b-30">Žiadosť číslo <?php echo e($request->id); ?></p>

                <div class="form-layout">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Meno:</label>
                                <input class="form-control" type="text" name="name" value="<?php echo e($request->user->name); ?>"
                                       disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label class="form-control-label">Oddelenie:</label>
                                <input class="form-control" type="text" name="department"
                                       value="<?php echo e($request->user->department->name); ?>" disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label class="form-control-label">Pozícia:</label>
                                <input class="form-control" type="text" name="position"
                                       value="<?php echo e($request->user->position->name); ?>" disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Emailová adresa:</label>
                                <input class="form-control" type="text" name="email" value="<?php echo e($request->user->email); ?>"
                                       disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Dôvod žiadosti:</label>
                                <textarea rows="3" id="reason" class="form-control" name="reason"
                                          disabled><?php echo e($request->reason); ?></textarea>
                            </div>
                        </div><!-- col-8 -->
                    </div><!-- row -->
                </div><!-- form-layout -->
            </div>
        </div>
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zariadenia</h6>
                <div class="form-layout">
                    <div class="row mg-b-25">
                        <?php $__currentLoopData = $request->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label"><?php echo e($device->type->name); ?></label>
                                    <input class="form-control" type="text"
                                           value="<?php echo e($device->name); ?> <?php echo e(!empty($device->serial_number) ? "|| SN:" . $device->serial_number : ""); ?>"
                                           disabled>
                                </div>
                            </div><!-- col-4 -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!-- row -->
                </div><!-- form-layout -->
            </div><!-- card -->
        </div><!-- card -->
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Vrátenie zariadení</h6>
                <div class="form-layout">
                    <form action="<?php echo e(route('request.return.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input hidden name="request_id" value="<?php echo e($request->id); ?>">
                        <?php $__currentLoopData = $request->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($device->type->type == 1): ?>
                                <h5><?php echo e($device->type->name); ?></h5>
                                <div class="row mg-b-25">
                                    <div class="col-lg-1 mg-t-30">
                                        <label class="ckbox">
                                            <input type="checkbox" name="<?php echo e($device->type->name); ?>-checkbox"><span><?php echo e($device->name); ?></span>
                                        </label>
                                    </div><!-- col-3 -->
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-control-label">Sériové číslo</label>
                                            <input class="form-control" type="text" placeholder="Skontrolvať pred odovzdaním" name="<?php echo e($device->type->name); ?>-serial">
                                        </div>
                                    </div><!-- col-4 -->
                                </div>
                            <?php else: ?>
                                <div class="row mg-b-25">
                                    <div class="col-lg-3 mg-t-20 mg-lg-t-0">
                                        <label class="ckbox">
                                            <input type="checkbox" name="<?php echo e($device->type->name); ?>-checkbox"><span><?php echo e($device->name); ?></span>
                                        </label>
                                    </div><!-- col-3 -->
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-layout-footer">
                            <button class="btn btn-info mg-r-5">Vrátiť</button>
                            <a href="<?php echo e(route('request.index')); ?>" class="btn btn-secondary">Zrušiť</a>
                        </div><!-- form-layout-footer -->
                    </form>
                </div><!-- form-layout -->
            </div><!-- card -->
        </div><!-- card -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/request/return.blade.php ENDPATH**/ ?>