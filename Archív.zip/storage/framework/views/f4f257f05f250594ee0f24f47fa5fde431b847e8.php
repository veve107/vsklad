<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('brands')); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Značky</h5>
            </div><!-- sl-page-title -->

            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zoznam značiek zariadení
                    <button class="btn btn-sm btn-warning"
                            id="addBrand"
                            style="float: right">Pridať novú značku
                    </button>
                </h6>

                <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                        <thead>
                        <tr>
                            <th class="wd-15p">ID</th>
                            <th class="wd-15p">Značka</th>
                            <th class="wd-20p">Akcia</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($brand->id); ?></td>
                                <td><?php echo e($brand->name); ?></td>
                                <td>
                                    <button class="btn btn-sm btn-info editButton"
                                            data-id="<?php echo e($brand->id); ?>"
                                            data-name="<?php echo e($brand->name); ?>">Editovať
                                    </button>
                                    ||
                                    <a href="<?php echo e(route('brand.delete', $brand->id)); ?>"
                                       class="btn btn-sm btn-danger"
                                       id="delete">Zmazať</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('#datatable1').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            $('#datatable2').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            // Select2
            $('.dataTables_length select').select2({minimumResultsForSearch: Infinity});

            $(".editButtosn").click(function () {
                $("#updateForm").attr("action", '<?php echo e(route('brand.update.dummy')); ?>/' + $(this).attr("data-id"));
                $("#updateName").val($(this).attr('data-name'));
            })

            $("#addBrand").click(function () {
                Swal.fire({
                    title: 'Pridanie novej značky',
                    html:
                        '<form id="createBrand" method="post" action="<?php echo e(route('brand.store')); ?>"> <?php echo e(csrf_field()); ?>' +
                        '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov značky">' +
                        '</form>',
                    focusConfirm: false,
                    customClass: 'swal2-overflow',
                    confirmButtonText: "Pridaj značku",
                    preConfirm: () => {
                        return []
                    },
                }).then(function (result) {
                    if (result.isConfirmed) {
                        $("#createBrand").submit();
                    }
                })
            });

            $(".editButton").click(function () {
                Swal.fire({
                    title: 'Upravenie názvu značky',
                    html:
                        '<form id="updateBrand" method="post" action="<?php echo e(route('brand.update.dummy')); ?>/' + $(this).attr('data-id') + '"> <?php echo e(csrf_field()); ?>' +
                        '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov značky" value="' + $(this).attr('data-name') + '" >' +
                        '</form>',
                    focusConfirm: false,
                    customClass: 'swal2-overflow',
                    confirmButtonText: "Uprav názov značky",
                    preConfirm: () => {
                        return []
                    },
                }).then(function (result) {
                    if (result.isConfirmed) {
                        $("#updateBrand").submit();
                    }
                })
            });
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hardware/brands.blade.php ENDPATH**/ ?>