<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>
    <!-- ########## START: MAIN PANEL ########## -->
    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('processRequest', $request)); ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul style="margin-bottom: 0!important;">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Spracovanie žiadosti</h6>
                <p class="mg-b-20 mg-sm-b-30">Žiadosť číslo <?php echo e($request->id); ?></p>

                <div class="form-layout">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Meno:</label>
                                <input class="form-control" type="text" name="name" value="<?php echo e($request->user->name); ?>"
                                       disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label class="form-control-label">Oddelenie:</label>
                                <input class="form-control" type="text" name="department"
                                       value="<?php echo e($request->user->department->name); ?>" disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-2">
                            <div class="form-group">
                                <label class="form-control-label">Pozícia:</label>
                                <input class="form-control" type="text" name="position"
                                       value="<?php echo e($request->user->position->name); ?>" disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-4">
                            <div class="form-group">
                                <label class="form-control-label">Emailová adresa:</label>
                                <input class="form-control" type="text" name="email" value="<?php echo e($request->user->email); ?>"
                                       disabled>
                            </div>
                        </div><!-- col-4 -->
                        <div class="col-lg-12">
                            <div class="form-group mg-b-10-force">
                                <label class="form-control-label">Dôvod žiadosti:</label>
                                <textarea rows="3" id="reason" class="form-control" name="reason"
                                          disabled><?php echo e($request->reason); ?></textarea>
                            </div>
                        </div><!-- col-8 -->
                    </div><!-- row -->
                </div><!-- form-layout -->
            </div>
        </div>
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <form action="<?php echo e(route('request.process.store', $request->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-layout">
                        <div class="row mg-b-25">
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <label class="form-control-label"><?php echo e($type->name); ?></label>
                                        <select id="<?php echo e($type->name); ?>_id" class="form-control select2-show-search"
                                                name="<?php echo e($type->name); ?>"
                                                data-placeholder="">
                                            <option label="Výber..." disabled selected></option>
                                            <?php $__currentLoopData = $type->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($device->status == 1): ?>
                                                    <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div><!-- col-4 -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($types->find('1')) || !empty($types->find('2'))): ?>
                                <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <label class="form-control-label"><?php echo e($accessory->name); ?></label>
                                            <select id="<?php echo e($accessory->name); ?>_id" class="form-control select2-show-search"
                                                    name="<?php echo e($accessory->name); ?>"
                                                    data-placeholder="">
                                                <option label="Výber..." disabled selected></option>
                                                <?php $__currentLoopData = $accessory->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($device->status == 1): ?>
                                                        <option value="<?php echo e($device->id); ?>"><?php echo e($device->name); ?></option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div><!-- col-4 -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div><!-- row -->

                        <div class="form-layout-footer">
                            <button class="btn btn-info mg-r-5">Uložiť</button>
                            <a href="<?php echo e(route('request.index')); ?>" class="btn btn-secondary">Zrušiť</a>
                        </div><!-- form-layout-footer -->
                    </div><!-- form-layout -->
                </form>
            </div><!-- card -->
        </div><!-- card -->
    </div><!-- sl-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/request/process.blade.php ENDPATH**/ ?>