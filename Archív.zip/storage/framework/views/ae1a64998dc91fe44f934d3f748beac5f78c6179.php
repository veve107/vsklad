<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('editProfile', $user)); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Oddelenia</h5>
            </div><!-- sl-page-title -->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            <?php endif; ?>
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Úprava profilu</h6>
                <p class="mg-b-20 mg-sm-b-30">Formulár pre úpravu používateľa</p>
                <form action="<?php echo e(route('user.update', $user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-layout">
                        <div class="row mg-b-25">
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Meno používateľa: <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" id="name" type="text" name="name"
                                           value="<?php echo e($user->name); ?>">
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Email: <span
                                            class="tx-danger">*</span></label>
                                    <input class="form-control" id="email" type="text" name="email"
                                           value="<?php echo e($user->email); ?>">
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Rola: <span class="tx-danger">*</span></label>
                                    <select id="role_id" class="form-control select2-show-search" name="role_id"
                                            data-placeholder="Vyber rolu">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->role_id == $role->id): ?>
                                                <option value="<?php echo e($role->id); ?>" selected="selected"><?php echo e($role->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Typ: <span class="tx-danger">*</span></label>
                                    <select id="position_id" class="form-control select2-show-search" name="position_id"
                                            data-placeholder="Vyber pozíciu">
                                        <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->position_id == $position->id): ?>
                                                <option value="<?php echo e($position->id); ?>" selected><?php echo e($position->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($position->id); ?>"><?php echo e($position->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Oddelenie: <span
                                            class="tx-danger">*</span></label>
                                    <select id="department_id" class="form-control select2-show-search" name="department_id"
                                            data-placeholder="Vyber oddelenie">
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($user->department_id == $department->id): ?>
                                                <option value="<?php echo e($department->id); ?>" selected><?php echo e($department->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                        </div><!-- row -->

                        <div class="form-layout-footer">
                            <button class="btn btn-info mg-r-5">Uprav používateľa</button>
                        </div><!-- form-layout-footer -->
                    </div><!-- form-layout -->
                </form>
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->

    <script>
        $(function () {

            'use strict';

            $('.select2').select2({
                minimumResultsForSearch: Infinity
            });

            // Select2 by showing the search
            $('.select2-show-search').select2({
                minimumResultsForSearch: '',
                width: '100%'
            });

            // Select2 with tagging support
            $('.select2-tag').select2({
                tags: true,
                tokenSeparators: [',', ' ']
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>