<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('addHardware')); ?>

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        <?php endif; ?>
        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Pridanie zariadenia</h6>
                <p class="mg-b-20 mg-sm-b-30">Formulár pre pridanie zariadenia</p>
                <form action="<?php echo e(route('hardware.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-layout">
                        <div class="row mg-b-25">
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Značka: <span class="tx-danger">*</span></label>
                                    <select id="brand_id" class="form-control select2-show-search" name="brand_id"
                                            data-placeholder="Vyber značku">
                                        <option label="Zvoľ značku" disabled></option>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Model: <span class="tx-danger">*</span></label>
                                    <input class="form-control" type="text" name="name" placeholder="Zadaj model">
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Typ: <span class="tx-danger">*</span></label>
                                    <select id="type_id" class="form-control select2-show-search" name="type_id"
                                            data-placeholder="Vyber typ">
                                        <option label="Zvoľ značku" disabled></option>
                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($type->id); ?>" data-type="<?php echo e($type->type); ?>"><?php echo e($type->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group mg-b-10-force">
                                    <label class="form-control-label">Objednávka: <span
                                            class="tx-danger">*</span></label>
                                    <select id="order_id" class="form-control select2-show-search" name="order_id"
                                            data-placeholder="Vyber objednávku">
                                        <option label="Zvoľ značku" disabled></option>
                                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($order->id); ?>"><?php echo e($order->order_number); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Sériové číslo: <span
                                            class="tx-danger hardware">*</span></label>
                                    <input class="form-control" type="text" name="serial_number"
                                           placeholder="Zadaj sériové číslo">
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Inventárne číslo: </label>
                                    <input class="form-control" type="text" name="inventory_number"
                                           placeholder="Zadaj inventárne číslo">
                                </div>
                            </div><!-- col-4 -->
                            <div class="col-lg-4 accessories" style="display: none">
                                <div class="form-group">
                                    <label class="form-control-label">Počet kusov: <span
                                            class="tx-danger hardware">*</span></label>
                                    <input class="form-control" type="number" name="stock"
                                           placeholder="Zadaj počet kusov">
                                </div>
                            </div><!-- col-4 -->
                        </div><!-- row -->

                        <div class="form-layout-footer">
                            <button class="btn btn-info mg-r-5">Pridaj zariadenie</button>
                        </div><!-- form-layout-footer -->
                    </div><!-- form-layout -->
                </form>
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->
    <script src="<?php echo e(asset('backend/lib/jquery/jquery.js')); ?>"></script>

    <script>
        $(function () {
            'use strict';
            $('.select2').select2({
                minimumResultsForSearch: Infinity
            });
            // Select2 by showing the search
            $('.select2-show-search').select2({
                minimumResultsForSearch: '',
                width: '100%'
            });

            // Select2 with tagging support
            $('.select2-tag').select2({
                tags: true,
                tokenSeparators: [',', ' ']
            });
            $("#type_id").change(function(){
                if($(this).find(':selected').attr('data-type') == 1 || $(this).find(':selected').attr('data-type') == 2){
                    $('.accessories').hide()
                    $('.hardware').show();
                }else {
                    $('.accessories').show()
                    $('.hardware').hide();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/hardware/add.blade.php ENDPATH**/ ?>