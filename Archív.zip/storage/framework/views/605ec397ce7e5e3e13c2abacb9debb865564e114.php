<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('departments')); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Oddelenia</h5>
            </div><!-- sl-page-title -->

            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zoznam oddelení <button class="btn btn-sm btn-warning" id="addDepartment" style="float: right">Pridať nové oddelenie</button>
                </h6>

                <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                        <thead>
                        <tr>
                            <th class="wd-15p">ID</th>
                            <th class="wd-15p">Názov oddelenia</th>
                            <th class="wd-20p">Akcia</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($department->id); ?></td>
                                <td><?php echo e($department->name); ?></td>
                                <td><button class="btn btn-sm btn-info editButton" data-id="<?php echo e($department->id); ?>" data-name="<?php echo e($department->name); ?>">Editovať</button> ||
                                    <a href="<?php echo e(route('department.delete', $department->id)); ?>"
                                       class="btn btn-sm btn-danger"
                                       id="delete">Zmazať</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('#datatable1').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            $('#datatable2').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            // Select2
            $('.dataTables_length select').select2({minimumResultsForSearch: Infinity});
        })
        $("#addDepartment").click(function () {
            Swal.fire({
                title: 'Pridanie nového oddelenia',
                html:
                    '<form id="createDepartment" method="post" action="<?php echo e(route('department.store')); ?>"> <?php echo e(csrf_field()); ?>' +
                    '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov oddelenia">' +
                    '</form>',
                focusConfirm: false,
                customClass: 'swal2-overflow',
                confirmButtonText: "Pridaj oddelenie",
                preConfirm: () => {
                    return []
                },
            }).then(function (result) {
                if (result.isConfirmed) {
                    $("#createDepartment").submit();
                }
            })
        });

        $(".editButton").click(function () {
            Swal.fire({
                title: 'Upravenie názvu pozície',
                html:
                    '<form id="updateDepartment" method="post" action="<?php echo e(route('department.update.dummy')); ?>/' + $(this).attr('data-id') + '"> <?php echo e(csrf_field()); ?>' +
                    '<input id="name" type="text" name="name" class="swal2-input" placeholder="Názov oddelenia" value="' + $(this).attr('data-name') + '" >' +
                    '</form>',
                focusConfirm: false,
                customClass: 'swal2-overflow',
                confirmButtonText: "Uprav názov oddelenia",
                preConfirm: () => {
                    return []
                },
            }).then(function (result) {
                if (result.isConfirmed) {
                    $("#updateDepartment").submit();
                }
            })
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/others/departments.blade.php ENDPATH**/ ?>