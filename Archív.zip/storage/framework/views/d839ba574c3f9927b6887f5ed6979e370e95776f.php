<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('backend/lib/datatables/jquery.dataTables.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>

    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('requests')); ?>

        <div class="sl-pagebody">
            <div class="sl-page-title">
                <h5>Žiadosti</h5>
            </div><!-- sl-page-title -->
            <div class="card pd-20 pd-sm-40">
                <h6 class="card-body-title">Zoznam žiadostí</h6>

                <div class="table-wrapper">
                    <table id="datatable1" class="table display responsive nowrap">
                        <thead>
                        <tr>
                            <th class="wd-15p">ID</th>
                            <th class="wd-15p">Typ</th>
                            <th class="wd-15p">Meno používateľa</th>
                            <th class="wd-15p">Oddelenie</th>
                            <th class="wd-20p">Akcia</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($request->user->id == \Illuminate\Support\Facades\Auth::user()->id || \Illuminate\Support\Facades\Auth::user()->role->id == 1): ?>
                                <tr>
                                    <td><?php echo e($request->id); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $request->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($type == $request->types->last()): ?>
                                                <?php echo e($type->name); ?>

                                            <?php else: ?>
                                                <?php echo e($type->name); ?>,
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($request->user->name); ?></td>
                                    <?php if($request->user->department == null): ?>
                                        <td>Nenastavené</td>
                                    <?php else: ?>
                                        <td><?php echo e($request->user->department->name); ?></td>
                                    <?php endif; ?>

                                    <td>
                                        <div class="btn-group" role="group">
                                            <?php if($request->state_id == 1): ?>
                                                <?php if(\Illuminate\Support\Facades\Auth::user()->role->id == 1): ?>
                                                    <a href="<?php echo e(route('request.process', $request->id)); ?>"
                                                       class="btn btn-sm btn-success pd-x-25">Spracovať</a>
                                                <?php else: ?>
                                                    <button
                                                        class="btn btn-sm btn-secondary pd-x-25">Čaká na spracovanie
                                                    </button>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('request.edit', $request->id)); ?>"
                                                   class="btn btn-sm btn-info pd-x-25">Editovať</a>

                                                <a href="<?php echo e(route('request.delete', $request->id)); ?>"
                                                   class="btn btn-sm btn-danger pd-x-25"
                                                   id="delete">Zmazať</a>
                                            <?php elseif($request->state_id == 2): ?>
                                                <?php if(\Illuminate\Support\Facades\Auth::user()->role->id == 1): ?>
                                                    <a href="<?php echo e(route('request.processForIssue', $request->id)); ?>"
                                                       class="btn btn-sm btn-primary pd-x-25">Pripraviť na výdaj</a>
                                                <?php else: ?>
                                                    <button
                                                        class="btn btn-sm btn-secondary pd-x-25">Čaká na výdaj
                                                    </button>
                                                <?php endif; ?>
                                            <?php elseif($request->state_id == 3): ?>
                                                <?php if($request->user->id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                                                    <a href="<?php echo e(route('request.receive', $request->id)); ?>"
                                                       class="btn btn-sm btn-warning pd-x-25 receiveButton">Prevziať</a>
                                                <?php else: ?>
                                                    <button
                                                        class="btn btn-sm btn-secondary pd-x-25">Čaká na prevzatie
                                                    </button>
                                                <?php endif; ?>
                                            <?php elseif($request->state_id == 4): ?>
                                                <?php if($request->user->id == \Illuminate\Support\Facades\Auth::user()->id): ?>
                                                    <a href="<?php echo e(route('request.return', $request->id)); ?>"
                                                       class="btn btn-sm btn-purple pd-x-25">Vrátiť</a>
                                                <?php else: ?>
                                                    <button
                                                        class="btn btn-sm btn-secondary pd-x-25">Vydané
                                                    </button>
                                                <?php endif; ?>
                                            <?php elseif($request->state_id == 5): ?>
                                                <?php if(\Illuminate\Support\Facades\Auth::user()->role->id == 1): ?>
                                                    <a href="<?php echo e(route('request.confirm', $request->id)); ?>"
                                                       class="btn btn-sm btn-teal pd-x-25">Potvrdiť vrátenie</a>
                                                <?php else: ?>
                                                    <button
                                                        class="btn btn-sm btn-secondary pd-x-25">Čaká sa na potvrdenie
                                                    </button>
                                                <?php endif; ?>
                                            <?php elseif($request->state_id == 6): ?>
                                                <button
                                                    class="btn btn-sm btn-secondary pd-x-25">Žiadosť ukončená
                                                </button>
                                            <?php endif; ?>

                                            <a href="<?php echo e(route('request.detail', $request->id)); ?>"
                                               class="btn btn-sm btn-teal pd-x-25">Detail</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div><!-- card -->
        </div>
    </div><!-- sl-mainpanel -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(function () {
            $('#datatable1').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            $('#datatable2').DataTable({
                responsive: true,
                language: {
                    url: '<?php echo e(asset('backend/lib/datatables/Slovak.json')); ?>'
                }
            });
            // Select2
            $('.dataTables_length select').select2({minimumResultsForSearch: Infinity});
        })
        $(".receiveButton").click(function (e) {
            e.preventDefault();
            let link = $(this).attr("href");
            Swal.fire({
                title: 'Súhlasíte s podmienkami a ste si vedomý svojich povinností po prebratí firemného hardvéru?',
                text: "Tento súhlas je nevratný!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Áno, súhlasím.',
                cancelButtonText: 'Nie, nesúhlasím.'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = link;
                }
            })
        });


    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/request/request_index.blade.php ENDPATH**/ ?>