<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/profile.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('admin_content'); ?>
    <div class="sl-mainpanel">
        <?php echo e(\Diglactic\Breadcrumbs\Breadcrumbs::render('profile', $user)); ?>

        <div class="sl-pagebody">
            <div class="card pd-20 pd-sm-40">
                <div class="sl-page-title">
                    <h5>Môj profil</h5>
                </div><!-- sl-page-title -->
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img
                                src="https://www.placecage.com/800/800"
                                alt=""/>
                        </div>
                    </div>
                    <div class="col-md-7">
                        <form method="post">
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="profile-head">
                                        <h5>
                                            <?php echo e($user->name); ?>

                                        </h5>
                                        <h6>
                                            <?php if(empty($user->department)): ?>
                                                Nenastavené
                                            <?php else: ?>
                                                <?php echo e($user->department->name); ?> - <?php echo e($user->position->name); ?>

                                            <?php endif; ?>
                                        </h6>
                                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home"
                                                   role="tab" aria-controls="home" aria-selected="true">Informácie</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#devices"
                                                   role="tab" aria-controls="profile" aria-selected="false">Žiadosti</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn profile-edit-btn">Upraviť profil</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="tab-content profile-tab" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home" role="tabpanel"
                                             aria-labelledby="home-tab">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Email</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <p><?php echo e($user->email); ?></p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label>Telefón</label>
                                                </div>
                                                <div class="col-md-6">
                                                    <p>
                                                        <?php if(empty($user->phone_number)): ?>
                                                            Nenastavené
                                                        <?php else: ?>
                                                            <?php echo e($user->phone_number); ?>

                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="devices" role="tabpanel" aria-labelledby="profile-tab">
                                            <?php $__currentLoopData = $user->requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <h5 class="tx-inverse" style="color: <?php echo e($request->state_id == 6 ? "red" : "green"); ?>">Žiadosť číslo: <?php echo e($request->id); ?> z dňa <?php echo e(\Carbon\Carbon::parse($request->created_at)->format('d.m.Y')); ?> <?php echo e($request->state_id == 6 ? "Ukončená" : "Aktívna"); ?></h5>
                                                    </div>
                                                    <?php $__currentLoopData = $request->devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="col-md-6">
                                                            <label><?php echo e($device->type->name); ?></label>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <p><?php echo e($device->brand->name); ?> <?php echo e($device->name); ?> <?php echo e(!empty($device->serial_number) ? "|| " . $device->serial_number : ""); ?></p>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <hr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>

            </div>
        </div><!-- card -->
    </div><!-- sl-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/profile.blade.php ENDPATH**/ ?>